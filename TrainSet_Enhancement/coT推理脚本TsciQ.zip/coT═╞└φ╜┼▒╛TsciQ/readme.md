Qwen_72B_class_reason_para.py  是图片场景识别的脚本
call_classreason_1.sh 是调用的shell脚本

Qwen_72B_class_reason_para_conversation.py 是对话场景识别的脚本
call_classreason_talk_1.sh 是调用的脚本

看prompt看 elif type_str =="5"的就行