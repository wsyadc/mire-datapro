# -*- coding: utf-8 -*-
import os
import dashscope
import json
import argparse
from tqdm import tqdm
import random
import base64

os.environ['PYTHONIOENCODING'] = 'utf-8'
#  base 64 编码格式
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')
def parse_args():
    parser = argparse.ArgumentParser(description="Detect span")
    parser.add_argument(
        "--infer_model",
        type=str,
        default=''
    )
    parser.add_argument(
        "--class_type",
        type=str,
        default=''
    )
    args = parser.parse_args()
    return args    



#check_str = input("需要处理的类别：")
#type_str = input("#选择应用的prompt类型(1、模型自由推理(不给模型类别信息)，要求推理格式。2、给出图片类别信息，3、给出图片类别信息并要求模型推理字数在100以内：)")
file_name = "E:\\天池比赛\\tianchi\\train\\train.json"

args = parse_args()
type_str = args.infer_model
check_str_id = args.class_type
# type_str = "5"
# check_str_id = "0"
#物流跟踪和退款页面
#check_str_list = ["实物拍摄","商品分类选项","商品头图","下单过程中出现异常","订单详情页面","支付页面","评论区截图页面","物流列表页面","物流跟踪页面","物流异常页面","退款页面","退货页面","换货页面","购物车页面","店铺页面","活动页面","优惠券领取页面","账户页面","投诉举报页面","平台介入页面","外部APP截图","商品详情页截图","其他类别图片"]
check_str_list_description ={"反馈密封性不好":"买家反馈商品密封性差会漏",
"是否好用":	"买家咨询商品是否好用",
"是否会生锈":	"咨询商品是否会生锈",
"排水方式":	"（适用产品：洗衣机、热水器）咨询商品排水方式",
"包装区别":	"咨询商品不同包装的区别",
"发货数量":	"咨询商品发货数量",
"反馈用后症状":	"买家反馈用完后引起的人体反应",
"商品材质":	"咨询商品具体材质，配件材质，填充物",
"功效功能":	"咨询商品功效功能",
"是否易褪色":	"咨询商品是否易褪色",
"适用季节":"咨询商品适用季节",
"能否调光":	"咨询商品光源/灯光/光线/亮度是否可调",
"版本款型区别":	"咨询两个版本/型号/款式/类型/套装/组合等区别，不包括商品数量/重量/尺寸类区别",
"单品推荐":	"消费者咨询能否帮助推荐一下某类/某个商品，非sku级别",
"用法用量":	"咨询商品使用方法/步骤/顺序，包括但不限于用量，使用时间，使用部位",
"控制方式":	"咨询商品如何控制，能否可以通过手机/电脑控制",
"上市时间":	"咨询商品的上市时间",
"商品规格":	"咨询商品的数量、重量、含量、容量",
"信号情况":	"咨询手机使用的信号是否良好，以及信号不佳如何处理",
"养护方法":	"咨询商品的养护方法",
"套装推荐":	"消费者希望能推荐一些套装",
"何时上货":	"咨询补货/上货时间",
"气泡":	"咨询贴膜如何避免产生气泡及除气泡方法"}
check_str_list = ["反馈密封性不好","是否好用","是否会生锈","排水方式","包装区别","发货数量",	"反馈用后症状",	"商品材质",	"功效功能",	"是否易褪色",
 "适用季节","能否调光",	"版本款型区别",	"单品推荐",	"用法用量",	"控制方式","上市时间",	"商品规格",	"信号情况",	"养护方法",	"套装推荐",	"何时上货",	"气泡"]
check_option = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
check_str = check_str_list[int(check_str_id)]

prompt1 = """
# 你是一个电商领域识图专家,可以理解消费者上传的软件截图或实物拍摄图。 

# 上传的图片属于如下的分类标签中的一类:
    [\"实物拍摄(含售后)\",\"商品分类选项\",\"商品头图\",\"商品详情页截图\",\"下单过程中出现异常（显示购买失败浮窗）\",\"订单详情页面\",\"支付页面\",\"评论区截图页面\",\"物流页面-物流列表页面\",\"物流页面-物流跟踪页面\",\"物流页面-物流异常页面\",\"退款页面\",\"退货页面\",\"换货页面\",\"购物车页面\",\"店铺页面\",\"活动页面\",\"优惠券领取页面\",\"账单/账户页面\",\"投诉举报页面\",\"平台介入页面\",\"外部APP截图\",\"其他类别图片\"]

# 各个标签的定义如下：
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "商品分类选项":商品颜色、规格选项。
    "商品头图":商品首页大图。
    "商品详情页截图":可能出现在商品详情页各个部分的截图。
    "下单过程中出现异常（显示购买失败浮窗）":下单过程中出现异常（显示购买失败浮窗）的截图。
    "订单详情页面":呈现出完整订单信息的订单页面。
    "支付页面":包含支付方式选择、支付成功的页面。
    "评论区截图页面":在淘宝APP内或其他APP内的评论区截图。
    "物流页面-物流列表页面":呈现出两个以上物流信息的页面。
    "物流页面-物流跟踪页面":呈现出物流运输路径的页面。
    "物流页面-物流异常页面":包含物流异常信息的页面。
    "退款页面":含有退款信息的页面。
    "退货页面":含有退货信息的页面。
    "换货页面":含有换货信息的页面。
    "购物车页面":淘宝购物车页面的列表图或金额计算图。
    "店铺页面":店铺首页截图。
    "活动页面":活动截图。
    "优惠券领取页面":店铺首页或活动页中领取优惠券的截图。
    "账单/账户页面":包含交易明细列表、资产列表、卡券红包列表等。
    "投诉举报页面":	投诉或举报页面。
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "平台介入页面":平台客服介入处理的截图。
    "外部APP截图":各种非淘宝、菜鸟APP的截图，包括京东、拼多多、短信、手机系统截图。
    "其他类别图片":拿不准的其他图片。

# 现在,请你根据图片中的信息按如下步骤逐步推理得到分类标签。
    推理步骤：
    这张图片显示的是xxxx页面,包含了xxxx等信息。符合类别"xxxx"的定义:"xxxx",因此，这张图片的分类标签是"xxxx
"""
prompt2="""
# 你是一个电商领域识图专家,可以理解消费者上传的软件截图或实物拍摄图。 

# 上传的图片属于如下的分类标签中的一类:
    [\"实物拍摄(含售后)\",\"商品分类选项\",\"商品头图\",\"商品详情页截图\",\"下单过程中出现异常（显示购买失败浮窗）\",\"订单详情页面\",\"支付页面\",\"评论区截图页面\",\"物流页面-物流列表页面\",\"物流页面-物流跟踪页面\",\"物流页面-物流异常页面\",\"退款页面\",\"退货页面\",\"换货页面\",\"购物车页面\",\"店铺页面\",\"活动页面\",\"优惠券领取页面\",\"账单/账户页面\",\"投诉举报页面\",\"平台介入页面\",\"外部APP截图\",\"其他类别图片\"]

# 各个标签的定义如下：
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "商品分类选项":商品颜色、规格选项。
    "商品头图":商品首页大图。
    "商品详情页截图":可能出现在商品详情页各个部分的截图。
    "下单过程中出现异常（显示购买失败浮窗）":下单过程中出现异常（显示购买失败浮窗）的截图。
    "订单详情页面":呈现出完整订单信息的订单页面。
    "支付页面":包含支付方式选择、支付成功的页面。
    "评论区截图页面":在淘宝APP内或其他APP内的评论区截图。
    "物流页面-物流列表页面":呈现出两个以上物流信息的页面。
    "物流页面-物流跟踪页面":呈现出物流运输路径的页面。
    "物流页面-物流异常页面":包含物流异常信息的页面。
    "退款页面":含有退款信息的页面。
    "退货页面":含有退货信息的页面。
    "换货页面":含有换货信息的页面。
    "购物车页面":淘宝购物车页面的列表图或金额计算图。
    "店铺页面":店铺首页截图。
    "活动页面":活动截图。
    "优惠券领取页面":店铺首页或活动页中领取优惠券的截图。
    "账单/账户页面":包含交易明细列表、资产列表、卡券红包列表等。
    "投诉举报页面":	投诉或举报页面。
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "平台介入页面":平台客服介入处理的截图。
    "外部APP截图":各种非淘宝、菜鸟APP的截图，包括京东、拼多多、短信、手机系统截图。
    "其他类别图片":拿不准的其他图片。

# 现在,请你根据图片中的信息以及类别标签的定义,按如下推理步骤解释这张图片的分类标签为"{}"的原因。
    推理步骤：
    这张图片显示的是xxxx页面,包含了xxxx等信息。符合类别"xxxx"的定义:"xxxx",因此，这张图片的分类标签是"xxxx
""".format(check_str)
prompt3 = """
# 你是一个电商领域识图专家,可以理解消费者上传的软件截图或实物拍摄图。 

# 上传的图片属于如下的分类标签中的一类:
    [\"实物拍摄(含售后)\",\"商品分类选项\",\"商品头图\",\"商品详情页截图\",\"下单过程中出现异常（显示购买失败浮窗）\",\"订单详情页面\",\"支付页面\",\"评论区截图页面\",\"物流页面-物流列表页面\",\"物流页面-物流跟踪页面\",\"物流页面-物流异常页面\",\"退款页面\",\"退货页面\",\"换货页面\",\"购物车页面\",\"店铺页面\",\"活动页面\",\"优惠券领取页面\",\"账单/账户页面\",\"投诉举报页面\",\"平台介入页面\",\"外部APP截图\",\"其他类别图片\"]

# 各个标签的定义如下：
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "商品分类选项":商品颜色、规格选项。
    "商品头图":商品首页大图。
    "商品详情页截图":可能出现在商品详情页各个部分的截图。
    "下单过程中出现异常（显示购买失败浮窗）":下单过程中出现异常（显示购买失败浮窗）的截图。
    "订单详情页面":呈现出完整订单信息的订单页面。
    "支付页面":包含支付方式选择、支付成功的页面。
    "评论区截图页面":在淘宝APP内或其他APP内的评论区截图。
    "物流页面-物流列表页面":呈现出两个以上物流信息的页面。
    "物流页面-物流跟踪页面":呈现出物流运输路径的页面。
    "物流页面-物流异常页面":包含物流异常信息的页面。
    "退款页面":含有退款信息的页面。
    "退货页面":含有退货信息的页面。
    "换货页面":含有换货信息的页面。
    "购物车页面":淘宝购物车页面的列表图或金额计算图。
    "店铺页面":店铺首页截图。
    "活动页面":活动截图。
    "优惠券领取页面":店铺首页或活动页中领取优惠券的截图。
    "账单/账户页面":包含交易明细列表、资产列表、卡券红包列表等。
    "投诉举报页面":	投诉或举报页面。
    "实物拍摄(含售后)":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。
    "平台介入页面":平台客服介入处理的截图。
    "外部APP截图":各种非淘宝、菜鸟APP的截图，包括京东、拼多多、短信、手机系统截图。
    "其他类别图片":拿不准的其他图片。

# 现在,请你根据图片中的信息以及类别标签的定义,按如下推理步骤解释这张图片的分类标签为"{}"的原因,请将推理字数限制在100字以内。
    推理步骤：
    这张图片显示的是xxxx页面,包含了xxxx等信息。符合类别"xxxx"的定义:"xxxx",因此，这张图片的分类标签是"xxxx
""".format(check_str)


prompt4='消费者上传图片: <image>\n你是一个电商领域识图专家,可以理解消费者上传的软件截图或实物拍摄图，请根据图片内容判断图片场景，并选择合适的分类标签。 \n以下是可以参考的图片场景分类标签：:\n[\"实物拍摄(含售后)\",\"商品分类选项\",\"商品头图\",\"商品详情页截图\",\"下单过程中出现异常（显示购买失败浮窗）\",\"订单详情页面\",\"支付页面\",\"评论区截图页面\",\"物流页面-物流列表页面\",\"物流页面-物流跟踪页面\",\"物流页面-物流异常页面\",\"退款页面\",\"退货页面\",\"换货页面\",\"购物车页面\",\"店铺页面\",\"活动页面\",\"优惠券领取页面\",\"账单/账户页面\",\"投诉举报页面\",\"平台介入页面\",\"外部APP截图\",\"其他类别图片\"]\n其中各个标签的定义如下：\n\"实物拍摄(含售后)\":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。\n\"商品分类选项\":商品颜色、规格选项。\n\"商品头图\":商品首页大图。\n\"商品详情页截图\":可能出现在商品详情页各个部分的截图。\n\"下单过程中出现异常（显示购买失败浮窗）\":下单过程中出现异常（显示购买失败浮窗）的截图。\n\"订单详情页面\":呈现出完整订单信息的订单页面。\n\"支付页面\":包含支付方式选择、支付成功的页面。\n\"评论区截图页面\":在淘宝APP内或其他APP内的评论区截图。\n\"物流页面-物流列表页面\":呈现出两个以上物流信息的页面。\n\"物流页面-物流跟踪页面\":呈现出物流运输路径的页面。\n\"物流页面-物流异常页面\":包含物流异常信息的页面。\n\"退款页面\":含有退款信息的页面。\n\"退货页面\":含有退货信息的页面。\n\"换货页面\":含有换货信息的页面。\n\"购物车页面\":淘宝购物车页面的列表图或金额计算图。\n\"店铺页面\":店铺首页截图。\n\"活动页面\":活动截图。\n\"优惠券领取页面\":店铺首页或活动页中领取优惠券的截图。\n\"账单/账户页面\":包含交易明细列表、资产列表、卡券红包列表等。\n\"投诉举报页面\":\t投诉或举报页面。\n\"实物拍摄(含售后)\":用户用相机实拍的照片，包括用户售后的照片（损坏、缺失、与描述不符），或者其他用相机实拍的图片。\n\"平台介入页面\":平台客服介入处理的截图。\n\"外部APP截图\":各种非淘宝、菜鸟APP的截图，包括京东、拼多多、短信、手机系统截图。\n\"其他类别图片\":拿不准的其他图片。\n现在已知图片场景分类标签为：' + check_str + '。\n请你根据图片中的信息，按照如下推理过程，逐步得到图片场景分类标签：' + check_str + '。注意，最终预测结果为：' + check_str + '。请你不要预测为其他类别。请将推理字数限制在100字以内：\n这张图片主要包含了xxxx（图片包含的主要信息）。由于xxxx（图片中与图片场景分类标签相关的信息）。因此，这张图片的场景分类标签是“xxxx（图片场景分类标签）”\n'




save_list=[]
print("start:{}\n".format(check_str))
with open(file_name, 'r',encoding="utf-8") as train_file:
    train_data = json.load(train_file)
    
    ### 如下两行如果出现断点，请取消注释，并将上次的断点id填入.并注意将save_path修改
    # flag = False ##指示是否到达上次的断点，Flase未还没到，True为到了
    # id_need_check = "4b94023a-6a7e-4044-ad97-86cf0a9c5647-348"


    for i in tqdm(range(0,len(train_data))):
        ## 断线重连
        # if train_data[i]['id'] == "4b94023a-6a7e-4044-ad97-86cf0a9c5647-348":
        #     break
            #flag = True
        # if flag == False:
        #     continue
        if (train_data[i]['id']=="9e2a1ebe-87c3-4547-b405-b592aaabfdab-1384"):
            continue
        if (check_str in train_data[i]['output']):  
            ###
            #1、模型自由推理(不给模型类别信息)，要求推理格式
            if type_str == "1":
                prompt = prompt1
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model1\\save_train_{}_1.json".format(check_str)
            #2、给出图片类别信息
            elif type_str == "2":
                prompt = prompt2
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model2\\save_train_{}_2.json".format(check_str)
            #3、给出图片类别信息并要求模型推理字数在100以内：
            elif type_str == "3":
                prompt = prompt3
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model3\\save_train_{}_3.json".format(check_str)
            elif type_str =="4":
                prompt = prompt4
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model4\\save_train_{}_4.json".format(check_str)
            elif type_str =="5":
                qusetion = "问题:你是一个电商客服专家，请根据用户与客服的多轮对话判断用户的意图分类标签。\n"
                contents = [{"text": qusetion}]
                #根据<image>将instruction分隔开,
                #print(train_data[i]['instruction'])
                talk_list = train_data[i]['instruction'].split("请根据用户与客服的多轮对话判断用户的意图分类标签。\n")[1]
                talk_list = talk_list.split("<用户与客服的对话 END>\n")[0]+"<用户与客服的对话 END>\n"
                #print(talk_list)
                talk = talk_list.split("<image>")
                #talk 里面有len(<image>)+1数量的文本
                contents.append({"text": talk[0]})
                for nums_image in range(0,len(train_data[i]['image'])):
                    contents.append({"image": train_data[i]['image'][nums_image]})
                    if talk[nums_image+1]!="":
                        contents.append({"text": talk[nums_image+1]})
                options = "分类的选项和对应描述如下:\n"
                split_str = "\n"
                check_str_list_keys = list(check_str_list_description.keys())
                if(check_str_list[int(check_str_id)]  not in check_str_list_keys[(int(check_str_id))]):
                    print("check_str_list_description的key值有误，请检查！\n")
                    break
                for n in range(0,len(check_str_list_description)):
                    options = options + check_option[n]+" "+ check_str_list_keys[n]+":{}".format(check_str_list_description[check_str_list_keys[n]])+"\n"
                #在图片场景识别中，只会有一张图片，所以这样做了，如果换到意图识别需要修改。
                correct_answer = "正确答案是:{}\n".format(check_option[int(check_str_id)]+check_str_list_keys[int(check_str_id)])
                instruction = "请给我一个详细的解释"
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model_talk_1\\save_train_{}_talk_1.json".format(check_str)
                #需要构造的是messages:
                contents.append({"text": options})
                contents.append({"text": correct_answer})
                contents.append({"text": instruction})
                messages_5 = [
                        {
                            "role": "user",
                            "content": contents
                        }
                    ]
                messages = messages_5
                #在prompt中限制解释在90字以内
            elif type_str =="6":
                qusetion = "问题:你是一个电商领域识图专家，请你对消费者上传的图片进行分类。\n"
                image_content = "图片:\n"
                options = "分类的选项和对应描述如下:\n"
                split_str = "\n"
                check_str_list_keys = list(check_str_list_description.keys())
                for n in range(0,len(check_str_list_description)):
                    options = options + check_option[n]+" "+ check_str_list_keys[n]+":{}".format(check_str_list_description[check_str_list_keys[n]])+"\n"
                #在图片场景识别中，只会有一张图片，所以这样做了，如果换到意图识别需要修改。
                correct_answer = "正确答案:{}\n".format(check_str_list_keys[int(check_str_id)])
                instruction = "请给我一个详细的解释,字数在90字以内"
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model6\\save_train_{}_6.json".format(check_str)
                #需要构造的是messages:
                messages_6 = [
                        {
                            "role": "user",
                            "content": [
                                {"text": qusetion},
                                {"text": image_content},
                                {"image": train_data[i]['image'][0]},
                                {"text": split_str},
                                {"text": options},
                                {"text": correct_answer},
                                {"text": instruction}
                            ]
                        }
                    ]
                messages = messages_6
            else:
                prompt = prompt3
                save_path="E:\\天池比赛\\tianchi\\train\\reasonbyQwen72b_model3\\save_train_{}_3.json".format(check_str)
                print("默认模式3\n")
            #在模式1，2，3，4下使用这一段messages
            # messages = [
            #     {
            #         "role": "user",
            #         "content": [
            #             {"text": prompt}]+
            #             [
            #             {"image": train_data[i]['image'][j]} for j in range(len(train_data[i]['image']))
            #         ]
            #     }
            # ]
            

            #print("id:\n{}\n".format(train_data[i]['id']))
            #出错情况下，会被取消注释
            #print("mrssages:{}\n".format(messages)) 
            response = dashscope.MultiModalConversation.call(
                # 若没有配置环境变量，请用百炼API Key将下行替换为：api_key="sk-xxx",
                api_key='sk-34fa10a0b6284713932f7aa7bf7c9c4f',
                model='qwen-vl-max',
                messages=messages,
                #max_tokens=100,
                )
            #print("当前的response:\n{}\n".format(response))
            train_data[i]["output"]=response['output']['choices'][0]['message']['content'][0]['text']

            train_data[i]["output_tokens"] = response['usage']['output_tokens']
            save_list.append(train_data[i])
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            with open(save_path, 'w',encoding="utf-8") as writer:
                json.dump(save_list, writer, ensure_ascii=False, indent=4)

print("{}Category inference completed, The result has been saved to{}\n".format(check_str_id,save_path))